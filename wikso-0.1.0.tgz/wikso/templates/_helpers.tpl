{{/*
Expand the name of the chart.
*/}}
{{- define "wikso.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "wikso.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart label values.
*/}}
{{- define "wikso.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels.
*/}}
{{- define "wikso.labels" -}}
helm.sh/chart: {{ include "wikso.chart" . }}
{{ include "wikso.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels.
*/}}
{{- define "wikso.selectorLabels" -}}
app.kubernetes.io/name: {{ include "wikso.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name.
*/}}
{{- define "wikso.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "wikso.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Backend image reference.
*/}}
{{- define "wikso.backend.image" -}}
{{- $tag := default .Chart.AppVersion .Values.backend.image.tag -}}
{{- printf "%s:%s" .Values.backend.image.repository $tag }}
{{- end }}

{{/*
Frontend image reference.
*/}}
{{- define "wikso.frontend.image" -}}
{{- $tag := default .Chart.AppVersion .Values.frontend.image.tag -}}
{{- printf "%s:%s" .Values.frontend.image.repository $tag }}
{{- end }}

{{/*
Meilisearch image reference.
*/}}
{{- define "wikso.meilisearch.image" -}}
{{- printf "%s:%s" .Values.meilisearch.image.repository .Values.meilisearch.image.tag }}
{{- end }}

{{/*
Secret name — use existing or generate.
*/}}
{{- define "wikso.secretName" -}}
{{- if .Values.secrets.existingSecret }}
{{- .Values.secrets.existingSecret }}
{{- else }}
{{- include "wikso.fullname" . }}
{{- end }}
{{- end }}

{{/*
PostgreSQL host — subchart or external.
*/}}
{{- define "wikso.postgresql.host" -}}
{{- if .Values.postgresql.enabled }}
{{- printf "%s-postgresql" .Release.Name }}
{{- else }}
{{- fail "External PostgreSQL is not yet supported. Enable the postgresql subchart." }}
{{- end }}
{{- end }}

{{/*
PostgreSQL database URL.
*/}}
{{- define "wikso.postgresql.url" -}}
{{- $host := include "wikso.postgresql.host" . -}}
{{- $db := default "wikso" .Values.postgresql.auth.database -}}
{{- $user := default "wikso" .Values.postgresql.auth.username -}}
{{- printf "postgresql://%s:$(POSTGRES_PASSWORD)@%s:5432/%s" $user $host $db }}
{{- end }}

{{/*
Redis host.
*/}}
{{- define "wikso.redis.host" -}}
{{- if .Values.redis.enabled }}
{{- printf "%s-redis-master" .Release.Name }}
{{- else }}
{{- fail "External Redis is not yet supported. Enable the redis subchart." }}
{{- end }}
{{- end }}

{{/*
S3 endpoint — MinIO subchart or external.
*/}}
{{- define "wikso.s3.endpoint" -}}
{{- if .Values.externalS3.enabled }}
{{- .Values.externalS3.endpoint }}
{{- else if .Values.minio.enabled }}
{{- printf "http://%s-minio:9000" .Release.Name }}
{{- else }}
{{- fail "Enable either minio subchart or externalS3." }}
{{- end }}
{{- end }}

{{/*
S3 port.
*/}}
{{- define "wikso.s3.port" -}}
{{- if .Values.externalS3.enabled }}
{{- .Values.externalS3.port }}
{{- else }}
{{- "9000" }}
{{- end }}
{{- end }}

{{/*
S3 SSL setting.
*/}}
{{- define "wikso.s3.useSSL" -}}
{{- if .Values.externalS3.enabled }}
{{- .Values.externalS3.useSSL }}
{{- else }}
{{- .Values.backend.env.s3UseSSL }}
{{- end }}
{{- end }}

{{/*
S3 bucket.
*/}}
{{- define "wikso.s3.bucket" -}}
{{- if .Values.externalS3.enabled }}
{{- .Values.externalS3.bucket }}
{{- else }}
{{- .Values.backend.env.s3Bucket }}
{{- end }}
{{- end }}

{{/*
S3 region.
*/}}
{{- define "wikso.s3.region" -}}
{{- if .Values.externalS3.enabled }}
{{- .Values.externalS3.region }}
{{- else }}
{{- .Values.backend.env.s3Region }}
{{- end }}
{{- end }}

{{/*
Meilisearch host.
*/}}
{{- define "wikso.meilisearch.host" -}}
{{- printf "http://%s-meilisearch:%d" (include "wikso.fullname" .) (int .Values.meilisearch.service.port) }}
{{- end }}

{{/*
PostgreSQL port (for backup CronJob).
*/}}
{{- define "wikso.postgresql.port" -}}
{{- "5432" }}
{{- end }}

{{/*
PostgreSQL user (for backup CronJob).
*/}}
{{- define "wikso.postgresql.user" -}}
{{- default "wikso" .Values.postgresql.auth.username }}
{{- end }}

{{/*
PostgreSQL database name (for backup CronJob).
*/}}
{{- define "wikso.postgresql.database" -}}
{{- default "wikso" .Values.postgresql.auth.database }}
{{- end }}

{{/*
PostgreSQL secret name — Bitnami subchart creates this automatically.
*/}}
{{- define "wikso.postgresql.secretName" -}}
{{- if .Values.postgresql.auth.existingSecret }}
{{- .Values.postgresql.auth.existingSecret }}
{{- else }}
{{- printf "%s-postgresql" .Release.Name }}
{{- end }}
{{- end }}

{{/*
PostgreSQL secret key for password.
*/}}
{{- define "wikso.postgresql.secretKey" -}}
{{- "password" }}
{{- end }}

{{/*
MinIO host (for backup CronJob).
*/}}
{{- define "wikso.minio.host" -}}
{{- printf "%s-minio" .Release.Name }}
{{- end }}

{{/*
MinIO port (for backup CronJob).
*/}}
{{- define "wikso.minio.port" -}}
{{- "9000" }}
{{- end }}

{{/*
MinIO secret name.
*/}}
{{- define "wikso.minio.secretName" -}}
{{- if .Values.minio.auth.existingSecret }}
{{- .Values.minio.auth.existingSecret }}
{{- else }}
{{- printf "%s-minio" .Release.Name }}
{{- end }}
{{- end }}
