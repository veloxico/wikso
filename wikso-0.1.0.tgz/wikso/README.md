# Wikso Helm Chart

A Helm chart for deploying [Wikso](https://github.com/veloxico/wikso) — the open-source, self-hosted knowledge base — on Kubernetes.

## Prerequisites

- Kubernetes 1.25+
- Helm 3.10+
- PV provisioner (for PostgreSQL, Redis, MinIO, and Meilisearch persistence)

## Quick Start

```bash
helm repo add bitnami https://charts.bitnami.com/bitnami
helm dependency build charts/wikso/

helm install wikso charts/wikso/ \
  --set secrets.jwtSecret=changeme \
  --set secrets.jwtRefreshSecret=changeme \
  --set secrets.meilisearchApiKey=changeme \
  --set postgresql.auth.password=changeme \
  --set secrets.redisPassword=changeme \
  --set minio.auth.rootUser=minioadmin \
  --set minio.auth.rootPassword=changeme
```

## Architecture

The chart deploys the following components:

| Component    | Kind         | Ports      | Description                                |
|-------------|-------------|------------|--------------------------------------------|
| Backend     | Deployment  | 3000, 1234 | NestJS API + HocusPocus WebSocket server   |
| Frontend    | Deployment  | 3000       | Next.js SSR frontend                       |
| Meilisearch | StatefulSet | 7700       | Full-text search engine (persistent data)  |
| Migration   | Job (hook)  | —          | Prisma DB migration (pre-install/upgrade)  |
| PostgreSQL  | Subchart    | 5432       | Primary database (Bitnami)                 |
| Redis       | Subchart    | 6379       | Caching and sessions (Bitnami)             |
| MinIO       | Subchart    | 9000       | Object storage for attachments (Bitnami)   |

## Parameters

### Global

| Parameter          | Description                      | Default |
|--------------------|----------------------------------|---------|
| `nameOverride`     | Override chart name              | `""`    |
| `fullnameOverride` | Override full release name       | `""`    |
| `imagePullSecrets` | Docker registry pull secrets     | `[]`    |

### Backend

| Parameter                                 | Description                          | Default               |
|-------------------------------------------|--------------------------------------|-----------------------|
| `backend.image.repository`                | Backend image                        | `veloxico/wikso-be`   |
| `backend.image.tag`                       | Image tag (default: appVersion)      | `""`                  |
| `backend.replicaCount`                    | Number of replicas                   | `1`                   |
| `backend.resources.limits.memory`         | Memory limit                         | `1Gi`                 |
| `backend.resources.limits.cpu`            | CPU limit                            | `1`                   |
| `backend.resources.requests.memory`       | Memory request                       | `256Mi`               |
| `backend.resources.requests.cpu`          | CPU request                          | `250m`                |
| `backend.service.type`                    | Service type                         | `ClusterIP`           |
| `backend.service.port`                    | API port                             | `3000`                |
| `backend.service.hocuspocusPort`          | WebSocket port                       | `1234`                |
| `backend.env.nodeEnv`                     | Node environment                     | `production`          |
| `backend.env.jwtExpiresIn`               | JWT token TTL                        | `15m`                 |
| `backend.env.jwtRefreshExpiresIn`        | Refresh token TTL                    | `7d`                  |
| `backend.env.emailVerificationRequired`  | Require email verification           | `false`               |
| `backend.env.s3Bucket`                   | S3 bucket name                       | `wikso-uploads`       |
| `backend.env.s3Region`                   | S3 region                            | `us-east-1`           |
| `backend.env.mailHost`                   | SMTP host                            | `""`                  |
| `backend.env.mailPort`                   | SMTP port                            | `587`                 |
| `backend.env.mailFrom`                   | Mail from address                    | `noreply@wikso.local` |
| `backend.env.frontendUrl`                | Public frontend URL                  | `""`                  |
| `backend.env.googleClientId`             | Google OAuth client ID               | `""`                  |
| `backend.env.githubClientId`             | GitHub OAuth client ID               | `""`                  |
| `backend.env.samlEntryPoint`             | SAML entry point URL                 | `""`                  |
| `backend.env.samlIssuer`                 | SAML issuer                          | `wikso`               |
| `backend.hpa.enabled`                    | Enable HPA                           | `false`               |
| `backend.hpa.minReplicas`               | HPA min replicas                     | `1`                   |
| `backend.hpa.maxReplicas`               | HPA max replicas                     | `5`                   |
| `backend.pdb.enabled`                    | Enable PDB                           | `false`               |
| `backend.pdb.minAvailable`              | PDB minimum available pods           | `1`                   |

### Frontend

| Parameter                                 | Description                          | Default               |
|-------------------------------------------|--------------------------------------|-----------------------|
| `frontend.image.repository`               | Frontend image                       | `veloxico/wikso-fe`   |
| `frontend.image.tag`                      | Image tag (default: appVersion)      | `""`                  |
| `frontend.replicaCount`                   | Number of replicas                   | `1`                   |
| `frontend.resources.limits.memory`        | Memory limit                         | `512Mi`               |
| `frontend.resources.limits.cpu`           | CPU limit                            | `500m`                |
| `frontend.service.type`                   | Service type                         | `ClusterIP`           |
| `frontend.service.port`                   | Frontend port                        | `3000`                |
| `frontend.env.publicApiUrl`              | Public backend API URL               | `""`                  |
| `frontend.env.publicWsUrl`              | Public WebSocket URL                 | `""`                  |
| `frontend.hpa.enabled`                   | Enable HPA                           | `false`               |
| `frontend.pdb.enabled`                   | Enable PDB                           | `false`               |

### Meilisearch

| Parameter                                 | Description                          | Default                    |
|-------------------------------------------|--------------------------------------|----------------------------|
| `meilisearch.image.repository`            | Meilisearch image                    | `getmeili/meilisearch`     |
| `meilisearch.image.tag`                   | Image tag                            | `v1.6`                     |
| `meilisearch.resources.limits.memory`     | Memory limit                         | `1Gi`                      |
| `meilisearch.service.port`               | Service port                         | `7700`                     |
| `meilisearch.persistence.size`           | PVC size                             | `10Gi`                     |
| `meilisearch.persistence.storageClass`   | Storage class                        | `""`                       |

### Secrets

| Parameter                      | Description                              | Default |
|--------------------------------|------------------------------------------|---------|
| `secrets.existingSecret`       | Use existing Secret name                 | `""`    |
| `secrets.jwtSecret`            | JWT signing secret **(required)**        | `""`    |
| `secrets.jwtRefreshSecret`     | JWT refresh secret **(required)**        | `""`    |
| `secrets.meilisearchApiKey`    | Meilisearch master key **(required)**    | `""`    |
| `secrets.redisPassword`        | Redis password                           | `""`    |
| `secrets.mailPass`             | SMTP password                            | `""`    |
| `secrets.googleClientSecret`   | Google OAuth secret                      | `""`    |
| `secrets.githubClientSecret`   | GitHub OAuth secret                      | `""`    |

### External S3

| Parameter                | Description                                | Default          |
|--------------------------|--------------------------------------------|------------------|
| `externalS3.enabled`     | Use external S3 instead of MinIO subchart  | `false`          |
| `externalS3.endpoint`    | S3-compatible endpoint URL                 | `""`             |
| `externalS3.port`        | S3 port                                    | `443`            |
| `externalS3.useSSL`      | Enable SSL                                 | `true`           |
| `externalS3.accessKey`   | Access key                                 | `""`             |
| `externalS3.secretKey`   | Secret key                                 | `""`             |
| `externalS3.bucket`      | Bucket name                                | `wikso-uploads`  |
| `externalS3.region`      | Region                                     | `us-east-1`      |

### Ingress

| Parameter               | Description                        | Default       |
|-------------------------|------------------------------------|---------------|
| `ingress.enabled`       | Enable Ingress                     | `false`       |
| `ingress.className`     | Ingress class name                 | `nginx`       |
| `ingress.annotations`   | Additional annotations             | `{}`          |
| `ingress.hosts`         | Hosts configuration                | See values    |
| `ingress.tls`           | TLS configuration                  | `[]`          |

### Subchart: PostgreSQL

| Parameter                              | Description          | Default  |
|----------------------------------------|----------------------|----------|
| `postgresql.enabled`                   | Deploy PostgreSQL    | `true`   |
| `postgresql.auth.username`             | Database user        | `wikso`  |
| `postgresql.auth.password`             | Database password    | `""`     |
| `postgresql.auth.database`             | Database name        | `wikso`  |
| `postgresql.primary.persistence.size`  | PVC size             | `10Gi`   |

### Subchart: Redis

| Parameter                        | Description        | Default  |
|----------------------------------|--------------------|----------|
| `redis.enabled`                  | Deploy Redis       | `true`   |
| `redis.auth.enabled`            | Enable auth        | `true`   |
| `redis.auth.password`           | Redis password     | `""`     |
| `redis.master.persistence.size` | PVC size           | `2Gi`    |
| `redis.replica.replicaCount`    | Replica count      | `0`      |

### Subchart: MinIO

| Parameter                    | Description             | Default          |
|------------------------------|-------------------------|------------------|
| `minio.enabled`              | Deploy MinIO            | `true`           |
| `minio.auth.rootUser`       | Root username           | `""`             |
| `minio.auth.rootPassword`   | Root password           | `""`             |
| `minio.persistence.size`    | PVC size                | `10Gi`           |
| `minio.defaultBuckets`      | Auto-create buckets     | `wikso-uploads`  |

## Using External S3

To use AWS S3, Cloudflare R2, or any S3-compatible storage instead of the MinIO subchart:

```yaml
minio:
  enabled: false

externalS3:
  enabled: true
  endpoint: https://s3.amazonaws.com
  port: "443"
  useSSL: "true"
  accessKey: AKIAIOSFODNN7EXAMPLE
  secretKey: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
  bucket: my-wikso-bucket
  region: us-west-2
```

## Ingress with WebSocket Support

The chart automatically configures path-based routing with WebSocket upgrade support:

```yaml
ingress:
  enabled: true
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/affinity: "cookie"
    nginx.ingress.kubernetes.io/session-cookie-name: "wikso-ws"
  hosts:
    - host: wikso.example.com
  tls:
    - secretName: wikso-tls
      hosts:
        - wikso.example.com
```

Routes:
- `/ws/*` → Backend WebSocket (port 1234)
- `/api/*` → Backend API (port 3000)
- `/*` → Frontend (port 3000)
